# weatherApp
Weather Website 
- pulling API's to request data 
- Displaying weather data 
- sorting of weather data
- region selection 
- weather timeline
